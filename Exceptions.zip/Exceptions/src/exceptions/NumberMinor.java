
package exceptions;

/**
 * 
 * @author David Pereira
 */
public class NumberMinor extends RuntimeException {
    public NumberMinor(String mensaje){
        super(mensaje);
    }

}
