
package exceptions;

import javax.swing.JOptionPane;

/**
 *
 * @author David Pereira
 */
public class Exceptions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        division();
    }

    //exepcion sin tratar
    public static void formatoNumero() {
        int numero;
        String cadena = "   1";
        try {
            numero = Integer.parseInt(cadena);
        } catch (NumberFormatException ex) {
            System.out.println("¡¡ERROR!! Debes ingresar un número, esto es un texto." + ex.getMessage());
        }

    }

    public static void desborde() {
        int v[] = new int[3];
        try {
            for (int i = 0; i < 5; i++) {
                v[i] = i;
            }
        } catch (ArrayIndexOutOfBoundsException mem) {
            System.out.println("No hay suficientes campos en el vector" + mem.getMessage());
        }
    }

    public static void aritmetico() {
        int numero = 5, resultado;
        try {
            resultado = numero / 0;
        } catch (ArithmeticException e) {
            System.out.println("¡No se puede dividir por 0!" + e.getMessage());
        }

    }

    public static void division() throws NumberMinor {
        int ent, div, res;
        ent = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número para dividir; tiene que ser entero:"));
        if (ent < 10) {
            throw new NumberMinor("¡El número no puede ser menor a 10!");
        }
        try {
            div = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dividendo para oprecaión:"));
            res = ent / div;
            JOptionPane.showMessageDialog(null, "Este es el resultado:" + res);
        } catch (ArithmeticException cer) {
            System.out.println("¡¡ERROR!! no es posible dividir por el número 0." + cer.getMessage());
        } catch (NumberFormatException form) {
            System.out.println("No es un Numero es una cadena de texto:  " + form.getMessage());
        }
    }

}
